#ifndef __NUMGEN_H__
#define __NUMGEN_H__
unsigned int numgen (unsigned int count, unsigned long int dest[]);
#endif
